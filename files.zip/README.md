# ⚽ Footy Predictor

A self-hosted football prediction mini-league for you and your friends. Pick scorelines for upcoming fixtures across the top 5 European leagues and the Champions League, earn points for correct results, and compete on a live leaderboard.

## Features

- 🏆 **6 competitions** — Premier League, La Liga, Serie A, Bundesliga, Ligue 1, Champions League
- 🔮 **Score predictions** — predict scorelines for upcoming fixtures before kickoff
- 📊 **Auto scoring** — 1pt for correct result, 3pts for exact score
- 🗄️ **SQLite database** — all predictions and results stored locally, no external DB needed
- 👤 **No accounts** — players just use a name + PIN, no email or signup required
- 🕐 **Local times** — all kickoff times shown in your local timezone

## Tech stack

- Node.js + Express
- SQLite (better-sqlite3)
- [football-data.org](https://www.football-data.org) API (free tier)
- Vanilla HTML/CSS/JS frontend

## Getting started

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/footy-predictor.git
cd footy-predictor
```

### 2. Install dependencies

```bash
npm install
```

### 3. Get a free API key

Sign up at [football-data.org](https://www.football-data.org/client/register) — it's free and takes 30 seconds.

### 4. Create your `.env` file

```bash
cp .env.example .env
```

Then open `.env` and paste your API key:

```
FOOTBALL_API_KEY=your_key_here
```

### 5. Run the server

```bash
node server.js
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## How to play

1. Go to `http://localhost:3000` to see upcoming fixtures
2. Go to `http://localhost:3000/predict.html` to submit predictions
3. Enter your name + a 4-digit PIN (first time auto-creates your account)
4. Pick a competition, enter your scorelines, hit Save
5. After matches finish, sync results to update scores

## Syncing results

To fetch latest results and score predictions, run:

```bash
curl -X POST http://localhost:3000/api/results/sync \
  -H "Content-Type: application/json" \
  -d '{"competition":"PL"}'
```

Replace `PL` with any competition code: `PD` (La Liga), `SA` (Serie A), `BL1` (Bundesliga), `FL1` (Ligue 1), `CL` (Champions League).

## Project structure

```
footy-predictor/
├── server.js        # Express backend + all API routes
├── db.js            # SQLite setup + table creation
├── public/
│   ├── index.html   # Fixtures viewer
│   └── predict.html # Prediction submission
├── .env.example     # API key template
└── package.json
```

## Roadmap

- [ ] Leaderboard page
- [ ] Player profile + history
- [ ] Weekly digest email
- [ ] Mobile-friendly UI polish

## License

MIT
